
with open("../DATA/tyger.txt") as tyger_in:
    for line in tyger_in:
        print(line, end='')
