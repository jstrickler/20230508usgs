user_name = 'Susan'
snake = 'Eastern Racer'
animal = 'wombat'
