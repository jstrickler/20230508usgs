def ham(n):
    return n * 10

