from collections import namedtuple

Card = namedtuple("Card", "rank suit".split())
