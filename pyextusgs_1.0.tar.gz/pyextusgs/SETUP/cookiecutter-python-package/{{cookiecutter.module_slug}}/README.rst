{{cookiecutter.package_name}}
{{'-' * (cookiecutter.package_name | length + 28)}}

README for {{cookiecutter.package_name}}. 

Please describe your project here. 


(c) {{cookiecutter.copyright_year}} {{cookiecutter.author_name}}
